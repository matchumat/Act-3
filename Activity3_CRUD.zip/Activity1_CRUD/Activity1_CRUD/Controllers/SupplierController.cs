﻿using Microsoft.AspNetCore.Mvc;
using AppDbContext;
using Microsoft.Data.SqlClient.DataClassification;

namespace Activity1_CRUD.Controllers
{
    public class SupplierController : Controller
    {

        private readonly Entprg12101094LimContext context;

        public SupplierController(Entprg12101094LimContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            return View(context.SupplierTbls.ToList());
        }

        public IActionResult Add()
        {

            return View(new SupplierTbl());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(SupplierTbl model) {
            context.Add(model);
            context.SaveChanges();
            return RedirectToAction("Index");
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int index)
        {
            var supplierTbl = context.SupplierTbls.Find(index);
            context.Set<SupplierTbl>().Remove(supplierTbl);
            context.SaveChanges();
            return RedirectToAction("Index");
        }


        public IActionResult Edit(int? id)
        {
            if (id == null) return RedirectToAction("Index");

            var supplierTbl = context.SupplierTbls.Find(id);
            return View(supplierTbl);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(SupplierTbl model)
        {
            context.Set<SupplierTbl>().Update(model);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
