﻿using System;
using System.Collections.Generic;

namespace AppDbContext;

public partial class TableJunctionTable
{
    public int ProductId { get; set; }

    public int SupplierId { get; set; }

    public DateTime? DateNow { get; set; }

    public virtual ProductTbl Product { get; set; } = null!;

    public virtual SupplierTbl Supplier { get; set; } = null!;
}
