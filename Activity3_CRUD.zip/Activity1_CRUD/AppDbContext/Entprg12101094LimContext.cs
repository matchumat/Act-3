﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AppDbContext;

public partial class Entprg12101094LimContext : DbContext
{
    public Entprg12101094LimContext()
    {
    }

    public Entprg12101094LimContext(DbContextOptions<Entprg12101094LimContext> options)
        : base(options)
    {
    }

    public virtual DbSet<DetailsMigration> DetailsMigrations { get; set; }

    public virtual DbSet<ProductTbl> ProductTbls { get; set; }

    public virtual DbSet<SupplierTbl> SupplierTbls { get; set; }

    public virtual DbSet<TableJunctionTable> TableJunctionTables { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=csb-entpro.wongph.com;Database=ENTPRG_12101094_LIM;User Id=12106751; Password=oW0vO5yO; TrustServerCertificate =true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DetailsMigration>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("DetailsMigration");

            entity.Property(e => e.ProductId).HasMaxLength(50);
            entity.Property(e => e.SupplierId).HasMaxLength(50);
        });

        modelBuilder.Entity<ProductTbl>(entity =>
        {
            entity.HasKey(e => e.ProductId);

            entity.ToTable("ProductTbl");

            entity.Property(e => e.Description).HasMaxLength(200);
            entity.Property(e => e.ProductDate).HasColumnType("datetime");
            entity.Property(e => e.ProductName).HasMaxLength(50);
        });

        modelBuilder.Entity<SupplierTbl>(entity =>
        {
            entity.HasKey(e => e.SupplierId);

            entity.ToTable("SupplierTbl");

            entity.Property(e => e.SupplierId).HasColumnName("supplierID");
            entity.Property(e => e.Address).HasMaxLength(50);
            entity.Property(e => e.Contact).HasMaxLength(12);
            entity.Property(e => e.DateAdded).HasColumnType("date");
            entity.Property(e => e.DateModified).HasColumnType("date");
            entity.Property(e => e.SupplierName)
                .HasMaxLength(50)
                .HasColumnName("supplierName");
        });

        modelBuilder.Entity<TableJunctionTable>(entity =>
        {
            entity.HasKey(e => new { e.ProductId, e.SupplierId });

            entity.ToTable("TableJunctionTable");

            entity.Property(e => e.DateNow).HasColumnType("date");

            entity.HasOne(d => d.Product).WithMany(p => p.TableJunctionTables)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TableJunctionTable_ProductTbl");

            entity.HasOne(d => d.Supplier).WithMany(p => p.TableJunctionTables)
                .HasForeignKey(d => d.SupplierId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TableJunctionTable_SupplierTbl");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
