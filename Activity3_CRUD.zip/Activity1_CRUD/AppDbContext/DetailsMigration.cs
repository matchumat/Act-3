﻿using System;
using System.Collections.Generic;

namespace AppDbContext;

public partial class DetailsMigration
{
    public int OrderDetailsId { get; set; }

    public string ProductId { get; set; } = null!;

    public string SupplierId { get; set; } = null!;

    public string SupplierName { get; set; } = null!;

    public string ProductName { get; set; } = null!;
}
