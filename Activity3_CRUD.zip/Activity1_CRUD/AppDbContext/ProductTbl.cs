﻿using System;
using System.Collections.Generic;

namespace AppDbContext;

public partial class ProductTbl
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public string Description { get; set; } = null!;

    public int Quantity { get; set; }

    public DateTime? ProductDate { get; set; }

    public virtual ICollection<TableJunctionTable> TableJunctionTables { get; set; } = new List<TableJunctionTable>();
}
